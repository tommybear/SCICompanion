// Talkers.sh -- Produced by SCI Companion
// This file should only be edited with the SCI Companion message editor

// 

(define NARRATOR 99)
(define NOBODY 1)

