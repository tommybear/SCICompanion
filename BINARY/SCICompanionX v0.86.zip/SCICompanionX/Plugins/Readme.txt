Install plugins here by placing them in a subfolder.

SCI Companion will scan for .exe files and list them in the plugins menu.

If invoked from SCI Companion, the executable will be passed the path to the game folder as command line argument

e.g.:

Plugins
    \Myplugin
           \Myplugin.exe
    \Anotherplugin
           \Anotherplguin.exe
           \somefile.dll
           \stuff