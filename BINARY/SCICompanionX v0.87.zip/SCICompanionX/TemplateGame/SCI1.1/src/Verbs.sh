// Verbs.sh -- Produced by SCI Companion
// This file should only be edited with the SCI Companion message editor

// VERBS

(define V_LOOK 1)
(define V_TALK 2)
(define V_WALK 3)
(define V_DO 4)
(define V_HELP 5)
(define V_COMBINE 7)

